package com.example.jaunt;

public class MyClass {
}