package com.example.demo;


import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.view.View;

import android.os.Bundle;
import android.widget.EditText;

import static com.example.demo.SecondActivity.CHANNEL_ID;

public class MainActivity extends AppCompatActivity {
    static final String em = "email", pass= "password";
    public void submit(View view) {
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        intent.putExtra(em,  email.getText().toString());
        intent.putExtra(pass, password.getText().toString());
        startActivity(intent);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        String textTitle, textContent;
//        textTitle = "Chegg";
//        textContent = "Question Available";
//
//
//
//
//
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
//                .setSmallIcon(R.drawable.notification)
//                .setContentTitle("My notification")
//                .setContentText("Hello World!")
//                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//                // Set the intent that will fire when the user taps the notification
////                                .setContentIntent(pendingIntent)
//                .setAutoCancel(true);
//        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
//        // notificationId is a unique int for each notification that you must define
//        int notificationId = 3;
//        notificationManager.notify(notificationId, builder.build());

    }
}