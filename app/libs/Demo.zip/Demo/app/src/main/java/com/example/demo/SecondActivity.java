package com.example.demo;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class SecondActivity extends AppCompatActivity {
    private static final int MY_SOCKET_TIMEOUT_MS = 60000 * 6;
    public static final int notificationId = 23323;
    public static final String CHANNEL_ID = "chegg_answering_app";
    public static String TAG = "hello";
    private WebView webView;
  
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        String email = intent.getStringExtra(MainActivity.em);
        String password = intent.getStringExtra(MainActivity.pass);


        //use of volley
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            String URL = "http://192.168.43.126:8000/api/";
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("username", email);
            jsonBody.put("password", password);
            final String requestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.i("VOLLEY", "the response is " + response);
                    String textTitle = "", textContent = "";

                    if(response == "available") {
                        textTitle = "Chegg";
                        textContent = "Question Available";
//                        private void createNotificationChannel() {
//                            // Create the NotificationChannel, but only on API 26+ because
//                            // the NotificationChannel class is new and not in the support library
//                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                                CharSequence name = getString(R.string.channel_name);
//                                String description = getString(R.string.channel_description);
//                                int importance = NotificationManager.IMPORTANCE_DEFAULT;
//                                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
//                                channel.setDescription(description);
//                                // Register the channel with the system; you can't change the importance
//                                // or other notification behaviors after this
//                                NotificationManager notificationManager = getSystemService(NotificationManager.class);
//                                notificationManager.createNotificationChannel(channel);
//                            }
//                        }




//                        NotificationCompat.Builder builder = new NotificationCompat.Builder(SecondActivity.this, CHANNEL_ID)
//                                .setSmallIcon(R.drawable.notification)
//                                .setContentTitle("My notification")
//                                .setContentText("Hello World!")
//                                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
//                                // Set the intent that will fire when the user taps the notification
////                                .setContentIntent(pendingIntent)
//                                .setAutoCancel(true);
//                                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(SecondActivity.this);
//                                // notificationId is a unique int for each notification that you must define
//                                notificationManager.notify(notificationId, builder.build());
                    }



                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("VOLLEY", error.toString());
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return requestBody == null ? null : requestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", requestBody, "utf-8");
                        return null;
                    }
                }

//                @Override
//                protected Response<String> parseNetworkResponse(NetworkResponse response) {
//                    String responseString = "";
//                    if (response != null) {
//                        responseString = String.valueOf(response);
//                        // can get more details such as response.headers
//                    }
//                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
//                }

            };
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


}